/** Automatically generated file. DO NOT MODIFY */
package com.example.poison_master;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}