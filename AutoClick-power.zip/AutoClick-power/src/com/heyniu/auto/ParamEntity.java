package com.heyniu.auto;

class ParamEntity {

	private String key;
	private String value;

	String getValue() {
		return value;
	}

	void setValue(String value) {
		this.value = value;
	}

	String getKey() {

		return key;
	}

	void setKey(String key) {
		this.key = key;
	}

}
